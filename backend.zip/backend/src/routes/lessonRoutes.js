import express from "express";
import {
  createLesson,
  getAllLessons,
  getLessonById,
  getLessonsByCourse,
} from "../controllers/lessonController.js";

const router = express.Router();

router.get("/courses/:id/lessons", getLessonsByCourse);
router.post("/", createLesson);
router.get("/", getAllLessons);
router.get("/:id", getLessonById);

export default router;

import express from "express";
import {
  createModule,
  getModules,
  getModuleById,
  getCoursesByModule,
} from "../controllers/moduleController.js";

const router = express.Router();

router.post("/", createModule);
router.get("/", getModules);
router.get("/:id", getModuleById);
router.get("/:id/courses", getCoursesByModule);

export default router;

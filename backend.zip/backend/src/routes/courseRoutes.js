import express from "express";
import {
  createCourse,
  getAllCourses,
  getCourseById,
  updateCourseLessons,
  getLessonsByCourseId,
} from "../controllers/courseController.js";

const router = express.Router();

router.post("/", createCourse);
router.get("/", getAllCourses);
router.get("/:id", getCourseById);
router.get("/:id/lessons", getLessonsByCourseId);
// router.get("/courses/:id/lessons", getLessonsByCourseId);
router.put("/:id/lessons", updateCourseLessons);

export default router;

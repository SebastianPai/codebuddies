import Lesson from "../models/LessonModel.js";
import Course from "../models/CourseModel.js";

// Obtener todas las lecciones de un módulo
export const getLessonsByModule = async (req, res) => {
  try {
    const { moduleId } = req.params;
    const lessons = await Lesson.find({ module: moduleId }).sort({ order: 1 });
    res.json(lessons);
  } catch (err) {
    res.status(500).json({ message: "Error al obtener lecciones" });
  }
};

// Obtener una lección por ID
export const getLessonById = async (req, res) => {
  try {
    const lesson = await Lesson.findById(req.params.id);
    if (!lesson)
      return res.status(404).json({ message: "Lección no encontrada" });
    res.json(lesson);
  } catch (err) {
    res.status(500).json({ message: "Error al obtener la lección" });
  }
};

// Crear una lección
export const createLesson = async (req, res) => {
  try {
    const { title, description, course, exercises } = req.body;

    const newLesson = new Lesson({
      title,
      description,
      course,
      exercises, // este ya es un array de objetos bien estructurados
    });

    await newLesson.save();

    res.status(201).json(newLesson);
  } catch (error) {
    console.error("❌ Error al crear lección:", error.message);
    res.status(500).json({ error: "Error interno del servidor" });
  }
};

// Actualizar una lección
export const updateLesson = async (req, res) => {
  try {
    const updated = await Lesson.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!updated)
      return res.status(404).json({ message: "Lección no encontrada" });
    res.json(updated);
  } catch (err) {
    res.status(500).json({ message: "Error al actualizar la lección" });
  }
};

// Eliminar una lección
export const deleteLesson = async (req, res) => {
  try {
    const deleted = await Lesson.findByIdAndDelete(req.params.id);
    if (!deleted)
      return res.status(404).json({ message: "Lección no encontrada" });
    res.json({ message: "Lección eliminada correctamente" });
  } catch (err) {
    res.status(500).json({ message: "Error al eliminar la lección" });
  }
};

// Obtener todas las lecciones
export const getAllLessons = async (req, res) => {
  try {
    const lessons = await Lesson.find(); // sin populate
    res.status(200).json(lessons);
  } catch (error) {
    console.error("Error en getAllLessons:", error.message);
    res.status(500).json({ message: "Error al obtener las lecciones" });
  }
};

// controllers/lessonController.js
export const getLessonsByCourse = async (req, res) => {
  try {
    const lessons = await Lesson.find({ course: req.params.id });
    res.json(lessons);
  } catch (error) {
    res.status(500).json({ message: "Error getting lessons" });
  }
};
